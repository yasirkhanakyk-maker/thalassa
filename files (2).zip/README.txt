THALASSA - go live in about 15 minutes
1. Buy a domain (e.g. thalassa-salon.com). Replace YOURDOMAIN.com in index.html, robots.txt, sitemap.xml.
2. Go to https://app.netlify.com/drop and drag this whole folder in. Attach your domain under Domain settings (free HTTPS).
3. Open the live site and submit a test booking. FormSubmit emails yasirkhan.akyk@gmail.com an ACTIVATION link the first time: click it (check spam). After that every booking arrives as a table email.
4. Customers get an automatic "request received" email. To CONFIRM, just reply to the booking email in Gmail: replies go to the customer's address.
5. Google: open https://search.google.com/search-console, add your domain, verify (Netlify DNS or HTML tag), then Sitemaps -> submit sitemap.xml. Listing takes days to weeks. Nobody can make it instant.
6. Replace sample address, phone, WhatsApp number (wa.me/NUMBER), prices and stylist names by editing index.html.
